variable "organization" {
  description = "Nom de l'organisation TFE."
  type        = string
}

variable "policy_set_name" {
  description = "Nom du policy set Sentinel."
  type        = string
}

variable "policy_set_description" {
  description = "Description du policy set."
  type        = string
  default     = null
}

variable "policy_kind" {
  description = "Type de moteur de policy : sentinel ou opa."
  type        = string
  default     = "sentinel"

  validation {
    condition     = contains(["sentinel", "opa"], var.policy_kind)
    error_message = "policy_kind doit être 'sentinel' ou 'opa'."
  }
}

variable "global" {
  description = "Si vrai, applique le policy set à tous les workspaces de l'organisation."
  type        = bool
  default     = false
}

variable "workspace_ids" {
  description = "Liste des workspace_id auxquels appliquer le policy set (ignoré si global = true)."
  type        = list(string)
  default     = []
}

variable "project_ids" {
  description = "Liste des project_id auxquels appliquer le policy set (ignoré si global = true)."
  type        = list(string)
  default     = []
}

variable "vcs_repo" {
  description = "Dépôt VCS contenant les policies Sentinel (alternative au mode 'policies' en ligne)."
  type = object({
    identifier     = string
    branch         = optional(string, "main")
    oauth_token_id = optional(string)
    ingress_submodules = optional(bool, false)
    policies_path   = optional(string)
  })
  default = null
}

variable "policies" {
  description = <<-EOT
    Map des policies Sentinel définies en ligne (utilisé si vcs_repo n'est pas défini).
    Clé = nom de la policy, valeur = objet {description, enforcement_level, content}.
    enforcement_level : advisory, soft-mandatory, hard-mandatory.
  EOT
  type = map(object({
    description       = optional(string, "")
    enforcement_level = string
    content           = string
  }))
  default = {}
}

variable "policy_set_parameters" {
  description = "Paramètres globaux transmis au policy set (utile pour les policies paramétrables)."
  type = map(object({
    value     = string
    sensitive = optional(bool, false)
  }))
  default = {}
}
