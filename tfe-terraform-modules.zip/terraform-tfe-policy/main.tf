# Policies Sentinel définies en ligne dans Terraform (mode "sans VCS").
resource "tfe_policy" "this" {
  for_each = var.vcs_repo == null ? var.policies : {}

  name              = each.key
  description       = each.value.description
  organization      = var.organization
  policy             = each.value.content
  enforce_mode      = each.value.enforcement_level
  kind              = var.policy_kind
}

resource "tfe_policy_set" "this" {
  name          = var.policy_set_name
  description   = var.policy_set_description
  organization  = var.organization
  kind          = var.policy_kind
  global        = var.global
  workspace_ids = var.global ? null : var.workspace_ids
  project_ids   = var.global ? null : var.project_ids

  # Mode "policies en ligne" : on rattache les policies créées ci-dessus.
  policy_ids = var.vcs_repo == null ? [for p in tfe_policy.this : p.id] : null

  dynamic "vcs_repo" {
    for_each = var.vcs_repo != null ? [var.vcs_repo] : []
    content {
      identifier          = vcs_repo.value.identifier
      branch              = vcs_repo.value.branch
      oauth_token_id      = vcs_repo.value.oauth_token_id
      ingress_submodules  = vcs_repo.value.ingress_submodules
    }
  }
}

resource "tfe_policy_set_parameter" "this" {
  for_each = var.policy_set_parameters

  key           = each.key
  value         = each.value.value
  sensitive     = each.value.sensitive
  policy_set_id = tfe_policy_set.this.id
}
