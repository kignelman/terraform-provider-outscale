# terraform-tfe-policy

Module Terraform pour créer un **policy set Sentinel (ou OPA)** dans Terraform Enterprise / Terraform Cloud, avec deux modes de fonctionnement :

1. **Mode VCS** : le policy set pointe vers un dépôt Git contenant les fichiers `.sentinel` et un `sentinel.hcl`.
2. **Mode inline** : les policies sont définies directement dans le code Terraform (`var.policies`), pratique pour un petit nombre de règles gérées depuis ce même module.

## Ressources gérées

| Ressource | Description |
|---|---|
| `tfe_policy` | Policies Sentinel définies en ligne (mode inline uniquement) |
| `tfe_policy_set` | Le policy set lui-même, rattaché à VCS ou aux policies inline |
| `tfe_policy_set_parameter` | Paramètres globaux du policy set |

## Utilisation — Mode VCS (recommandé pour un référentiel de policies conséquent)

```hcl
module "policy_set_security" {
  source = "git::https://gitlab.example.com/terraform-modules/terraform-tfe-policy.git?ref=v1.0.0"

  organization            = "mon-entreprise"
  policy_set_name         = "security-baseline"
  policy_set_description  = "Règles de sécurité obligatoires"
  global                  = true

  vcs_repo = {
    identifier     = "mon-organisation/sentinel-policies"
    branch         = "main"
    oauth_token_id = "ot-xxxxxxxxxxxx"
    policies_path  = "security/"
  }
}
```

## Utilisation — Mode inline (petit nombre de policies)

```hcl
module "policy_set_tags" {
  source = "git::https://gitlab.example.com/terraform-modules/terraform-tfe-policy.git?ref=v1.0.0"

  organization    = "mon-entreprise"
  policy_set_name = "mandatory-tags"
  workspace_ids   = ["ws-xxxxxxxxxxxx"]

  policies = {
    "require-owner-tag" = {
      enforcement_level = "hard-mandatory"
      content           = file("${path.module}/sentinel-policies/require-owner-tag.sentinel")
    }
  }
}
```

## Inputs

| Nom | Description | Type | Défaut | Requis |
|---|---|---|---|---|
| organization | Nom de l'organisation | string | - | oui |
| policy_set_name | Nom du policy set | string | - | oui |
| policy_set_description | Description | string | `null` | non |
| policy_kind | `sentinel` ou `opa` | string | `sentinel` | non |
| global | Applique à tous les workspaces | bool | `false` | non |
| workspace_ids | Workspaces ciblés | list(string) | `[]` | non |
| project_ids | Projets ciblés | list(string) | `[]` | non |
| vcs_repo | Dépôt Git des policies | object | `null` | non |
| policies | Policies définies en ligne | map(object) | `{}` | non |
| policy_set_parameters | Paramètres globaux du policy set | map(object) | `{}` | non |

## Outputs

| Nom | Description |
|---|---|
| policy_set_id | ID du policy set |
| policy_set_name | Nom du policy set |
| policy_ids | IDs des policies inline créées |

## Exemple

Voir [`examples/basic`](./examples/basic), qui inclut un exemple de policy Sentinel prête à l'emploi.

## Note

- N'utilisez pas `vcs_repo` et `policies` en même temps : le module privilégie `vcs_repo` s'il est renseigné.
- `enforcement_level` accepte : `advisory`, `soft-mandatory`, `hard-mandatory`.
