terraform {
  required_version = ">= 1.5.0"

  required_providers {
    tfe = {
      source  = "hashicorp/tfe"
      version = ">= 0.51.0"
    }
  }
}

provider "tfe" {}

module "policy_set_tags" {
  source = "../../"

  organization    = "mon-entreprise"
  policy_set_name = "mandatory-tags"
  global          = true

  policies = {
    "require-owner-tag" = {
      description       = "Toute ressource taggable doit porter un tag owner"
      enforcement_level = "hard-mandatory"
      content           = file("${path.module}/sentinel-policies/require-owner-tag.sentinel")
    }
  }
}

output "policy_set_id" {
  value = module.policy_set_tags.policy_set_id
}
