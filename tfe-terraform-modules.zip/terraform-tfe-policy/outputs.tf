output "policy_set_id" {
  description = "ID du policy set créé."
  value       = tfe_policy_set.this.id
}

output "policy_set_name" {
  description = "Nom du policy set créé."
  value       = tfe_policy_set.this.name
}

output "policy_ids" {
  description = "IDs des policies créées en ligne (vide si mode VCS)."
  value       = { for k, p in tfe_policy.this : k => p.id }
}
