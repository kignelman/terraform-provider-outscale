terraform {
  required_version = ">= 1.5.0"

  required_providers {
    tfe = {
      source  = "hashicorp/tfe"
      version = ">= 0.51.0"
    }
  }
}

provider "tfe" {
  # hostname = "tfe.mon-entreprise.com"  # requis si TFE on-prem
  # token défini via la variable d'environnement TFE_TOKEN
}

module "organization" {
  source = "../../"

  name                     = "mon-entreprise-demo"
  email                    = "devops@mon-entreprise.com"
  collaborator_auth_policy = "two_factor_mandatory"
  cost_estimation_enabled  = true

  members = {
    "alice@mon-entreprise.com" = {}
    "bob@mon-entreprise.com"   = {}
  }

  create_organization_token = true
}

output "organization_id" {
  value = module.organization.organization_id
}
