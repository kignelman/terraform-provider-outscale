variable "name" {
  description = "Nom de l'organisation Terraform Enterprise."
  type        = string
}

variable "email" {
  description = "Adresse e-mail de contact/admin de l'organisation."
  type        = string
}

variable "collaborator_auth_policy" {
  description = "Politique d'authentification des collaborateurs. Valeurs possibles : password, two_factor_mandatory."
  type        = string
  default     = "two_factor_mandatory"
}

variable "session_timeout_minutes" {
  description = "Durée d'inactivité avant expiration de session (minutes)."
  type        = number
  default     = 20160
}

variable "session_remember_minutes" {
  description = "Durée de mémorisation de session (minutes)."
  type        = number
  default     = 20160
}

variable "cost_estimation_enabled" {
  description = "Active l'estimation des coûts sur l'organisation."
  type        = bool
  default     = true
}

variable "owners_team_saml_role_id" {
  description = "ID du rôle SAML mappé à l'équipe owners (laisser null si SSO non utilisé)."
  type        = string
  default     = null
}

variable "assessments_enforced" {
  description = "Force le health assessment (drift detection) sur tous les workspaces éligibles."
  type        = bool
  default     = false
}

variable "allow_force_delete_workspaces" {
  description = "Autorise la suppression forcée des workspaces contenant des ressources gérées."
  type        = bool
  default     = false
}

variable "members" {
  description = "Map des membres à inviter dans l'organisation. Clé = email, valeur = objet d'options d'invitation."
  type = map(object({
    organization_access = optional(object({
      manage_policies         = optional(bool, false)
      manage_policy_overrides = optional(bool, false)
      manage_workspaces       = optional(bool, false)
      manage_vcs_settings     = optional(bool, false)
      manage_projects         = optional(bool, false)
      manage_membership       = optional(bool, false)
    }), {})
  }))
  default = {}
}

variable "create_organization_token" {
  description = "Si vrai, génère un token d'API au niveau de l'organisation."
  type        = bool
  default     = false
}

variable "organization_token_force_regenerate" {
  description = "Force la régénération du token d'organisation à chaque apply."
  type        = bool
  default     = false
}
