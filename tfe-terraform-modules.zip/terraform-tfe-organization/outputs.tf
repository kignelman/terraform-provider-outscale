output "organization_id" {
  description = "ID de l'organisation créée."
  value       = tfe_organization.this.id
}

output "organization_name" {
  description = "Nom de l'organisation créée."
  value       = tfe_organization.this.name
}

output "member_emails" {
  description = "Liste des membres invités dans l'organisation."
  value       = keys(var.members)
}

output "organization_token" {
  description = "Token d'API de l'organisation (si généré)."
  value       = try(tfe_organization_token.this[0].token, null)
  sensitive   = true
}
