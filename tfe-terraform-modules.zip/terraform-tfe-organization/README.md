# terraform-tfe-organization

Module Terraform pour créer et configurer une **organisation Terraform Enterprise / Terraform Cloud**.

## Ressources gérées

| Ressource | Description |
|---|---|
| `tfe_organization` | Création de l'organisation |
| `tfe_organization_membership` | Invitation des membres |
| `tfe_organization_token` | Génération optionnelle d'un token d'API organisation |

## Utilisation

```hcl
module "organization" {
  source = "git::https://gitlab.example.com/terraform-modules/terraform-tfe-organization.git?ref=v1.0.0"

  name                      = "mon-entreprise"
  email                     = "devops@mon-entreprise.com"
  collaborator_auth_policy  = "two_factor_mandatory"
  cost_estimation_enabled   = true

  members = {
    "alice@mon-entreprise.com" = {}
    "bob@mon-entreprise.com"   = {}
  }

  create_organization_token = true
}
```

## Inputs

| Nom | Description | Type | Défaut | Requis |
|---|---|---|---|---|
| name | Nom de l'organisation | string | - | oui |
| email | Email de contact | string | - | oui |
| collaborator_auth_policy | Politique d'authentification | string | `two_factor_mandatory` | non |
| session_timeout_minutes | Timeout de session | number | `20160` | non |
| session_remember_minutes | Durée de mémorisation | number | `20160` | non |
| cost_estimation_enabled | Active l'estimation de coûts | bool | `true` | non |
| owners_team_saml_role_id | ID rôle SAML owners | string | `null` | non |
| assessments_enforced | Force le health assessment | bool | `false` | non |
| allow_force_delete_workspaces | Autorise suppression forcée | bool | `false` | non |
| members | Map des membres à inviter | map(object) | `{}` | non |
| create_organization_token | Génère un token d'organisation | bool | `false` | non |
| organization_token_force_regenerate | Force la régénération du token | bool | `false` | non |

## Outputs

| Nom | Description |
|---|---|
| organization_id | ID de l'organisation |
| organization_name | Nom de l'organisation |
| member_emails | Liste des emails invités |
| organization_token | Token API (sensible) |

## Exemple

Voir [`examples/basic`](./examples/basic).

## Pré-requis

- Terraform >= 1.5.0
- Provider `hashicorp/tfe` >= 0.51.0
- Variable d'environnement `TFE_TOKEN` (token admin) et `TFE_HOSTNAME` si instance TFE on-prem.
