resource "tfe_organization" "this" {
  name                          = var.name
  email                         = var.email
  collaborator_auth_policy      = var.collaborator_auth_policy
  session_timeout_minutes       = var.session_timeout_minutes
  session_remember_minutes      = var.session_remember_minutes
  cost_estimation_enabled       = var.cost_estimation_enabled
  owners_team_saml_role_id      = var.owners_team_saml_role_id
  assessments_enforced          = var.assessments_enforced
  allow_force_delete_workspaces = var.allow_force_delete_workspaces
}

resource "tfe_organization_membership" "this" {
  for_each = var.members

  organization = tfe_organization.this.name
  email        = each.key
}

# Permissions détaillées par membre (nécessite tfe_team_organization_member
# ou un mapping vers l'équipe "owners" géré ici pour les accès organisation).
resource "tfe_organization_membership" "access" {
  for_each = { for k, v in var.members : k => v if v.organization_access != null }

  organization = tfe_organization.this.name
  email        = each.key
}

resource "tfe_organization_token" "this" {
  count = var.create_organization_token ? 1 : 0

  organization    = tfe_organization.this.name
  force_regenerate = var.organization_token_force_regenerate
}
