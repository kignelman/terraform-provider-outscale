resource "tfe_workspace" "this" {
  name                   = var.name
  organization           = var.organization
  project_id             = var.project_id
  description            = var.description
  terraform_version      = var.terraform_version
  working_directory      = var.working_directory
  auto_apply             = var.auto_apply
  execution_mode         = var.execution_mode
  queue_all_runs         = var.queue_all_runs
  file_triggers_enabled  = var.file_triggers_enabled
  trigger_patterns       = var.trigger_patterns
  tag_names              = var.tags
  global_remote_state    = var.global_remote_state
  remote_state_consumer_ids = var.global_remote_state ? null : var.remote_state_consumer_ids

  dynamic "vcs_repo" {
    for_each = var.vcs_repo != null ? [var.vcs_repo] : []
    content {
      identifier                  = vcs_repo.value.identifier
      branch                       = vcs_repo.value.branch
      oauth_token_id               = vcs_repo.value.oauth_token_id
      github_app_installation_id   = vcs_repo.value.github_app_installation_id
    }
  }
}

resource "tfe_variable" "terraform" {
  for_each = var.terraform_variables

  key          = each.key
  value        = each.value.value
  category     = "terraform"
  sensitive    = each.value.sensitive
  description  = each.value.description
  hcl          = each.value.hcl
  workspace_id = tfe_workspace.this.id
}

resource "tfe_variable" "environment" {
  for_each = var.environment_variables

  key          = each.key
  value        = each.value.value
  category     = "env"
  sensitive    = each.value.sensitive
  description  = each.value.description
  workspace_id = tfe_workspace.this.id
}

resource "tfe_team_access" "this" {
  for_each = var.team_access

  team_id      = each.key
  workspace_id = tfe_workspace.this.id
  access       = each.value
}
