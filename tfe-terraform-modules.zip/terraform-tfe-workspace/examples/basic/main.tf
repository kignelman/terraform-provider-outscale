terraform {
  required_version = ">= 1.5.0"

  required_providers {
    tfe = {
      source  = "hashicorp/tfe"
      version = ">= 0.51.0"
    }
  }
}

provider "tfe" {}

module "workspace_prod_network" {
  source = "../../"

  organization       = "mon-entreprise"
  name               = "prod-network"
  description        = "Infrastructure réseau de production"
  terraform_version  = "~> 1.7.0"
  auto_apply         = false

  vcs_repo = {
    identifier     = "mon-organisation/infra-network"
    branch         = "main"
    oauth_token_id = "ot-xxxxxxxxxxxx"
  }

  terraform_variables = {
    region = { value = "eu-west-1" }
  }

  environment_variables = {
    AWS_DEFAULT_REGION = { value = "eu-west-1" }
  }

  team_access = {
    "team-xxxxxxxxxxxx" = "write"
  }
}

output "workspace_id" {
  value = module.workspace_prod_network.workspace_id
}
