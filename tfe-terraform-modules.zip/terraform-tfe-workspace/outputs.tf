output "workspace_id" {
  description = "ID du workspace créé."
  value       = tfe_workspace.this.id
}

output "workspace_name" {
  description = "Nom du workspace créé."
  value       = tfe_workspace.this.name
}

output "workspace_url" {
  description = "URL relative du workspace (à combiner avec le hostname TFE)."
  value       = "${var.organization}/workspaces/${tfe_workspace.this.name}"
}
