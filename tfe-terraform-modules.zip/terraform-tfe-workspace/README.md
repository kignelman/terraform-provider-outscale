# terraform-tfe-workspace

Module Terraform pour créer un **workspace** Terraform Enterprise / Terraform Cloud avec sa configuration VCS, ses variables et ses accès d'équipe.

## Ressources gérées

| Ressource | Description |
|---|---|
| `tfe_workspace` | Création du workspace |
| `tfe_variable` (terraform) | Variables Terraform |
| `tfe_variable` (env) | Variables d'environnement |
| `tfe_team_access` | Accès des équipes au workspace |

## Utilisation

```hcl
module "workspace_prod_network" {
  source = "git::https://gitlab.example.com/terraform-modules/terraform-tfe-workspace.git?ref=v1.0.0"

  organization = "mon-entreprise"
  project_id   = "prj-xxxxxxxxxxxx"
  name         = "prod-network"
  description  = "Infrastructure réseau de production"

  terraform_version = "~> 1.7.0"
  execution_mode     = "remote"
  auto_apply         = false

  vcs_repo = {
    identifier     = "mon-organisation/infra-network"
    branch         = "main"
    oauth_token_id = "ot-xxxxxxxxxxxx"
  }

  terraform_variables = {
    region = { value = "eu-west-1" }
  }

  environment_variables = {
    AWS_DEFAULT_REGION = { value = "eu-west-1" }
    AWS_ACCESS_KEY_ID   = { value = "xxxx", sensitive = true }
  }

  team_access = {
    "team-xxxxxxxxxxxx" = "write"
    "team-yyyyyyyyyyyy" = "read"
  }
}
```

## Inputs

| Nom | Description | Type | Défaut | Requis |
|---|---|---|---|---|
| organization | Nom de l'organisation | string | - | oui |
| project_id | ID du projet parent | string | `null` | non |
| name | Nom du workspace | string | - | oui |
| description | Description | string | `null` | non |
| terraform_version | Contrainte de version Terraform | string | `~> 1.7.0` | non |
| working_directory | Répertoire de travail VCS | string | `null` | non |
| auto_apply | Apply automatique | bool | `false` | non |
| execution_mode | `remote`, `local` ou `agent` | string | `remote` | non |
| queue_all_runs | Mise en file dès création | bool | `false` | non |
| file_triggers_enabled | Déclenchement sur fichiers modifiés | bool | `true` | non |
| trigger_patterns | Patterns de déclenchement | list(string) | `[]` | non |
| vcs_repo | Configuration VCS | object | `null` | non |
| tags | Tags du workspace | list(string) | `[]` | non |
| terraform_variables | Variables Terraform | map(object) | `{}` | non |
| environment_variables | Variables d'environnement | map(object) | `{}` | non |
| team_access | Map team_id => accès | map(string) | `{}` | non |
| remote_state_consumer_ids | Workspaces consommateurs du state | list(string) | `[]` | non |
| global_remote_state | State accessible à tous | bool | `false` | non |

## Outputs

| Nom | Description |
|---|---|
| workspace_id | ID du workspace |
| workspace_name | Nom du workspace |
| workspace_url | URL relative du workspace |

## Exemple

Voir [`examples/basic`](./examples/basic).
