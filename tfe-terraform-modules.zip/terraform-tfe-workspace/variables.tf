variable "organization" {
  description = "Nom de l'organisation TFE."
  type        = string
}

variable "project_id" {
  description = "ID du projet auquel rattacher le workspace (voir module terraform-tfe-project)."
  type        = string
  default     = null
}

variable "name" {
  description = "Nom du workspace."
  type        = string
}

variable "description" {
  description = "Description du workspace."
  type        = string
  default     = null
}

variable "terraform_version" {
  description = "Version de Terraform à utiliser pour ce workspace."
  type        = string
  default     = "~> 1.7.0"
}

variable "working_directory" {
  description = "Répertoire de travail dans le dépôt VCS."
  type        = string
  default     = null
}

variable "auto_apply" {
  description = "Applique automatiquement les plans réussis."
  type        = bool
  default     = false
}

variable "execution_mode" {
  description = "Mode d'exécution : remote, local ou agent."
  type        = string
  default     = "remote"
}

variable "queue_all_runs" {
  description = "Met en file d'attente tous les runs dès la création du workspace."
  type        = bool
  default     = false
}

variable "file_triggers_enabled" {
  description = "Déclenche les runs uniquement sur changement de fichiers dans working_directory / trigger_patterns."
  type        = bool
  default     = true
}

variable "trigger_patterns" {
  description = "Patterns de fichiers déclenchant un run."
  type        = list(string)
  default     = []
}

variable "vcs_repo" {
  description = "Configuration du dépôt VCS lié au workspace."
  type = object({
    identifier     = string
    branch         = optional(string, "main")
    oauth_token_id = optional(string)
    github_app_installation_id = optional(string)
  })
  default = null
}

variable "tags" {
  description = "Tags appliqués au workspace."
  type        = list(string)
  default     = []
}

variable "terraform_variables" {
  description = "Variables Terraform (HCL) à injecter dans le workspace. Clé = nom, valeur = objet {value, sensitive, description}."
  type = map(object({
    value       = string
    sensitive   = optional(bool, false)
    description = optional(string, "")
    hcl         = optional(bool, false)
  }))
  default = {}
}

variable "environment_variables" {
  description = "Variables d'environnement à injecter dans le workspace."
  type = map(object({
    value       = string
    sensitive   = optional(bool, false)
    description = optional(string, "")
  }))
  default = {}
}

variable "team_access" {
  description = "Map des accès équipe au workspace. Clé = team_id, valeur = niveau d'accès (admin, write, read, plan, custom)."
  type        = map(string)
  default     = {}
}

variable "remote_state_consumer_ids" {
  description = "IDs des workspaces autorisés à consommer le remote state de ce workspace (si global_remote_state = false)."
  type        = list(string)
  default     = []
}

variable "global_remote_state" {
  description = "Rend le remote state accessible à tous les workspaces de l'organisation."
  type        = bool
  default     = false
}
