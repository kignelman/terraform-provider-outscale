resource "tfe_project" "this" {
  organization                   = var.organization
  name                            = var.name
  description                     = var.description
  auto_destroy_activity_duration  = var.auto_destroy_activity_duration
}

resource "tfe_team_project_access" "this" {
  for_each = var.team_access

  team_id    = each.key
  project_id = tfe_project.this.id
  access     = each.value
}
