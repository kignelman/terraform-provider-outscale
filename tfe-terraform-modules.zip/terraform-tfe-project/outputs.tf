output "project_id" {
  description = "ID du projet créé."
  value       = tfe_project.this.id
}

output "project_name" {
  description = "Nom du projet créé."
  value       = tfe_project.this.name
}
