terraform {
  required_version = ">= 1.5.0"

  required_providers {
    tfe = {
      source  = "hashicorp/tfe"
      version = ">= 0.51.0"
    }
  }
}

provider "tfe" {}

module "project" {
  source = "../../"

  organization = "mon-entreprise"
  name         = "plateforme-paiement"
  description  = "Ressources cloud de la plateforme de paiement"

  team_access = {
    "team-xxxxxxxxxxxx" = "write"
  }
}

output "project_id" {
  value = module.project.project_id
}
