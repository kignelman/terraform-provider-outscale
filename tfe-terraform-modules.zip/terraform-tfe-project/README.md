# terraform-tfe-project

Module Terraform pour créer un **projet** Terraform Enterprise / Terraform Cloud, permettant de regrouper des workspaces et de gérer les accès d'équipe au niveau projet.

## Ressources gérées

| Ressource | Description |
|---|---|
| `tfe_project` | Création du projet |
| `tfe_team_project_access` | Accès des équipes au projet |

## Utilisation

```hcl
module "project" {
  source = "git::https://gitlab.example.com/terraform-modules/terraform-tfe-project.git?ref=v1.0.0"

  organization = "mon-entreprise"
  name         = "plateforme-paiement"
  description  = "Ressources cloud de la plateforme de paiement"

  team_access = {
    "team-xxxxxxxxxxxx" = "write"
    "team-yyyyyyyyyyyy" = "read"
  }
}
```

## Inputs

| Nom | Description | Type | Défaut | Requis |
|---|---|---|---|---|
| organization | Nom de l'organisation | string | - | oui |
| name | Nom du projet | string | - | oui |
| description | Description du projet | string | `null` | non |
| auto_destroy_activity_duration | Durée avant auto-destruction | string | `null` | non |
| team_access | Map team_id => niveau d'accès | map(string) | `{}` | non |

## Outputs

| Nom | Description |
|---|---|
| project_id | ID du projet |
| project_name | Nom du projet |

## Exemple

Voir [`examples/basic`](./examples/basic).
