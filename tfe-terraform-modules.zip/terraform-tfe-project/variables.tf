variable "organization" {
  description = "Nom de l'organisation TFE dans laquelle créer le projet."
  type        = string
}

variable "name" {
  description = "Nom du projet."
  type        = string
}

variable "description" {
  description = "Description du projet (optionnelle)."
  type        = string
  default     = null
}

variable "auto_destroy_activity_duration" {
  description = "Durée d'inactivité avant auto-destruction des workspaces du projet (ex: '14d', '24h'). Null pour désactiver."
  type        = string
  default     = null
}

variable "team_access" {
  description = "Map des accès équipe au projet. Clé = team_id, valeur = niveau d'accès (admin, write, read, maintain, custom)."
  type        = map(string)
  default     = {}

  validation {
    condition     = alltrue([for v in values(var.team_access) : contains(["admin", "write", "read", "maintain", "no-access"], v)])
    error_message = "Les valeurs de team_access doivent être : admin, write, read, maintain ou no-access."
  }
}
