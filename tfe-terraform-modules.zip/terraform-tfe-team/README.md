# terraform-tfe-team

Module Terraform pour créer une **équipe (team)** Terraform Enterprise / Terraform Cloud, gérer ses membres, ses permissions organisation et ses accès aux workspaces.

## Ressources gérées

| Ressource | Description |
|---|---|
| `tfe_team` | Création de l'équipe |
| `tfe_team_organization_member` | Ajout des membres à l'équipe |
| `tfe_team_access` | Accès de l'équipe aux workspaces |
| `data.tfe_organization_membership` | Résolution email → membership pour ajouter des membres |

## Utilisation

```hcl
module "team_devops" {
  source = "git::https://gitlab.example.com/terraform-modules/terraform-tfe-team.git?ref=v1.0.0"

  organization = "mon-entreprise"
  name         = "devops"
  visibility   = "organization"

  organization_access = {
    manage_workspaces = true
    manage_projects   = true
  }

  member_emails = [
    "alice@mon-entreprise.com",
    "bob@mon-entreprise.com"
  ]

  workspace_access = {
    "ws-xxxxxxxxxxxx" = "write"
  }
}
```

## Inputs

| Nom | Description | Type | Défaut | Requis |
|---|---|---|---|---|
| organization | Nom de l'organisation | string | - | oui |
| name | Nom de l'équipe | string | - | oui |
| visibility | `secret` ou `organization` | string | `organization` | non |
| sso_team_id | ID SSO mappé | string | `null` | non |
| organization_access | Permissions au niveau organisation | object | `{}` | non |
| member_emails | Emails des membres à ajouter | list(string) | `[]` | non |
| workspace_access | Map workspace_id => niveau d'accès | map(string) | `{}` | non |

## Outputs

| Nom | Description |
|---|---|
| team_id | ID de l'équipe |
| team_name | Nom de l'équipe |

## Exemple

Voir [`examples/basic`](./examples/basic).

## Dépendances logiques

Ce module suppose que l'organisation (module `terraform-tfe-organization`) et, si des membres sont fournis, leur invitation, existent déjà.
