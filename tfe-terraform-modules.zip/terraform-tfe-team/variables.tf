variable "organization" {
  description = "Nom de l'organisation TFE dans laquelle créer l'équipe."
  type        = string
}

variable "name" {
  description = "Nom de l'équipe."
  type        = string
}

variable "visibility" {
  description = "Visibilité de l'équipe : secret ou organization."
  type        = string
  default     = "organization"

  validation {
    condition     = contains(["secret", "organization"], var.visibility)
    error_message = "visibility doit être 'secret' ou 'organization'."
  }
}

variable "sso_team_id" {
  description = "Identifiant SSO externe mappé à cette équipe (SAML/OIDC)."
  type        = string
  default     = null
}

variable "organization_access" {
  description = "Permissions de l'équipe au niveau organisation."
  type = object({
    manage_policies         = optional(bool, false)
    manage_policy_overrides = optional(bool, false)
    manage_workspaces       = optional(bool, false)
    manage_vcs_settings     = optional(bool, false)
    manage_projects         = optional(bool, false)
    manage_membership       = optional(bool, false)
    manage_teams             = optional(bool, false)
    manage_organization_access = optional(bool, false)
    manage_run_tasks        = optional(bool, false)
    read_projects            = optional(bool, false)
    read_workspaces          = optional(bool, false)
  })
  default = {}
}

variable "member_emails" {
  description = "Liste des emails des membres à ajouter à l'équipe. Ces utilisateurs doivent déjà être membres de l'organisation (cf. module terraform-tfe-organization)."
  type        = list(string)
  default     = []
}

variable "workspace_access" {
  description = "Map des accès workspace pour cette équipe. Clé = workspace_id, valeur = niveau d'accès (admin, write, read, plan, custom)."
  type        = map(string)
  default     = {}
}
