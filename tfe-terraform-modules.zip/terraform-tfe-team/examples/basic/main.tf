terraform {
  required_version = ">= 1.5.0"

  required_providers {
    tfe = {
      source  = "hashicorp/tfe"
      version = ">= 0.51.0"
    }
  }
}

provider "tfe" {}

module "team_devops" {
  source = "../../"

  organization = "mon-entreprise"
  name         = "devops"
  visibility   = "organization"

  organization_access = {
    manage_workspaces = true
    manage_projects   = true
  }

  member_emails = [
    "alice@mon-entreprise.com"
  ]
}

output "team_id" {
  value = module.team_devops.team_id
}
