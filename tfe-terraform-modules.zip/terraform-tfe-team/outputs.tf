output "team_id" {
  description = "ID de l'équipe créée."
  value       = tfe_team.this.id
}

output "team_name" {
  description = "Nom de l'équipe créée."
  value       = tfe_team.this.name
}
