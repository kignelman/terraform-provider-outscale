resource "tfe_team" "this" {
  name         = var.name
  organization = var.organization
  visibility   = var.visibility
  sso_team_id  = var.sso_team_id

  organization_access {
    manage_policies             = var.organization_access.manage_policies
    manage_policy_overrides     = var.organization_access.manage_policy_overrides
    manage_workspaces           = var.organization_access.manage_workspaces
    manage_vcs_settings         = var.organization_access.manage_vcs_settings
    manage_projects             = var.organization_access.manage_projects
    manage_membership           = var.organization_access.manage_membership
    manage_teams                = var.organization_access.manage_teams
    manage_organization_access  = var.organization_access.manage_organization_access
    manage_run_tasks            = var.organization_access.manage_run_tasks
    read_projects                = var.organization_access.read_projects
    read_workspaces              = var.organization_access.read_workspaces
  }
}

data "tfe_organization_membership" "this" {
  for_each = toset(var.member_emails)

  organization = var.organization
  email        = each.key
}

resource "tfe_team_organization_member" "this" {
  for_each = toset(var.member_emails)

  team_id                    = tfe_team.this.id
  organization_membership_id = data.tfe_organization_membership.this[each.key].id
}

resource "tfe_team_access" "this" {
  for_each = var.workspace_access

  team_id      = tfe_team.this.id
  workspace_id = each.key
  access       = each.value
}
